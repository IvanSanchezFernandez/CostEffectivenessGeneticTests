####Copyleft Ivan Sanchez Fernandez 2018



########################################PACKAGES########################################
library(shiny)
library(meta)
########################################PACKAGES########################################












##########################################################################################################################
##########################################################BEGINNNING OF UI################################################
##########################################################################################################################
#### ui.R
ui <- fluidPage( 
  # Beginning of fluidPage
  
  tags$br(),
  tags$strong("METAANALYSIS OF THE DIAGNOSTIC YIELD OF GENETIC TESTS IN EPILEPSY OF UNKNOWN ETIOLOGY: Interactively summarize the best available evidence."),
  tags$br(),
  tags$header("This app is optimized for a full-screen computer or tablet. Please, maximize this window."),
  tags$header("Remember to enter appropriate inputs into the model: with inappropriate inputs the model will return inappropriate outputs or errors."),
  tags$strong("If some of the cells are empty the app returns error: WHEN YOU ADD OR MODIFY A STUDY, COMPLETE ALL CELLS TO ELIMINATE THE ERRORS AND SEE RESULTS."),
  tags$br(),
  tags$br(),
  
  sidebarLayout(
    # Beginning of sidebarLayout
    
#########################################BEGINNING OF INPUT########################################################    
    ### INPUT
    sidebarPanel(
      # Beginning of sidebarPanel
      
      fluidRow(
        # Beginning of fluidRow
        
        # Title
        tags$strong("INPUT"),    
        tags$br(),
        tags$br(),
        
        
        # Buttons for adding and removing rows
        actionButton("add", "Add new study", icon = icon("plus", class = NULL)),
        
        tags$br(),
        tags$br(),
        column(2, tags$strong("Genetic test")), 
        column(4, tags$strong("Study")),
        column(2, tags$strong("N diagnosis")),
        column(2, tags$strong("N total")),
        column(2, tags$strong("Remove study")),
        
        
        #### PLACEHOLDER FOR THE ROWS
        # Placeholder for the rows
        tags$div(id = "placeholder"),
        
#######################################################################################################################################################        
        ########################################STUDIES THAT APPEAR AT BASELINE (IN THE EXISTING LITERATURE TODAY)#####################################
        ## FIRST BASELINE STUDY
        tags$div(
          id = 1,
          fluidRow(
            column(2, textInput(inputId = "genetictest1", label = NULL, value = "CMA")
            ),
            column(4, textInput(inputId = "studyname1", label = NULL, value = "Mefford et al, 2010")
            ),
            column(2, textInput(inputId = "ndiagnosed1", label = NULL, value = "46")
            ),
            column(2, textInput(inputId = "ntotal1", label = NULL, value = "517")
            ),
            column(2, actionButton(inputId = "remove1", label = "", icon = icon("times", class = NULL)))
          )),
        
        ## SECOND BASELINE STUDY
        tags$div(
          id = 2,
          fluidRow(
            column(2, textInput(inputId = "genetictest2", label = NULL, value = "CMA")
            ),
            column(4, textInput(inputId = "studyname2", label = NULL, value = "Mefford et al, 2011")
            ),
            column(2, textInput(inputId = "ndiagnosed2", label = NULL, value = "13")
            ),
            column(2, textInput(inputId = "ntotal2", label = NULL, value = "315")
            ),
            column(2, actionButton(inputId = "remove2", label = "", icon = icon("times", class = NULL)))
          )),
        
        
        ## THIRD BASELINE STUDY
        tags$div(
          id = 3,
          fluidRow(
            column(2, textInput(inputId = "genetictest3", label = NULL, value = "CMA")
            ),
            column(4, textInput(inputId = "studyname3", label = NULL, value = "Bartnik et al, 2012")
            ),
            column(2, textInput(inputId = "ndiagnosed3", label = NULL, value = "10")
            ),
            column(2, textInput(inputId = "ntotal3", label = NULL, value = "102")
            ),
            column(2, actionButton(inputId = "remove3", label = "", icon = icon("times", class = NULL)))
          )),
        
        
        ## FOURTH BASELINE STUDY
        tags$div(
          id = 4,
          fluidRow(
            column(2, textInput(inputId = "genetictest4", label = NULL, value = "CMA")
            ),
            column(4, textInput(inputId = "studyname4", label = NULL, value = "Michaud et al, 2014")
            ),
            column(2, textInput(inputId = "ndiagnosed4", label = NULL, value = "6")
            ),
            column(2, textInput(inputId = "ntotal4", label = NULL, value = "44")
            ),
            column(2, actionButton(inputId = "remove4", label = "", icon = icon("times", class = NULL)))
          )),
        
        
        ## FIFTH BASELINE STUDY
        tags$div(
          id = 5,
          fluidRow(
            column(2, textInput(inputId = "genetictest5", label = NULL, value = "CMA")
            ),
            column(4, textInput(inputId = "studyname5", label = NULL, value = "Helbig et al, 2014")
            ),
            column(2, textInput(inputId = "ndiagnosed5", label = NULL, value = "16")
            ),
            column(2, textInput(inputId = "ntotal5", label = NULL, value = "223")
            ),
            column(2, actionButton(inputId = "remove5", label = "", icon = icon("times", class = NULL)))
          )),
        
        
        ## SIXTH BASELINE STUDY
        tags$div(
          id = 6,
          fluidRow(
            column(2, textInput(inputId = "genetictest6", label = NULL, value = "CMA")
            ),
            column(4, textInput(inputId = "studyname6", label = NULL, value = "Olson et al, 2014")
            ),
            column(2, textInput(inputId = "ndiagnosed6", label = NULL, value = "40")
            ),
            column(2, textInput(inputId = "ntotal6", label = NULL, value = "805")
            ),
            column(2, actionButton(inputId = "remove6", label = "", icon = icon("times", class = NULL)))
          )),
        
        
        ## SEVENTH BASELINE STUDY
        tags$div(
          id = 7,
          fluidRow(
            column(2, textInput(inputId = "genetictest7", label = NULL, value = "CMA")
            ),
            column(4, textInput(inputId = "studyname7", label = NULL, value = "Hrabik et al, 2015")
            ),
            column(2, textInput(inputId = "ndiagnosed7", label = NULL, value = "11")
            ),
            column(2, textInput(inputId = "ntotal7", label = NULL, value = "147")
            ),
            column(2, actionButton(inputId = "remove7", label = "", icon = icon("times", class = NULL)))
          )),
        
        
        ## EIGHTH BASELINE STUDY
        tags$div(
          id = 8,
          fluidRow(
            column(2, textInput(inputId = "genetictest8", label = NULL, value = "CMA")
            ),
            column(4, textInput(inputId = "studyname8", label = NULL, value = "Berg et al, 2017")
            ),
            column(2, textInput(inputId = "ndiagnosed8", label = NULL, value = "32")
            ),
            column(2, textInput(inputId = "ntotal8", label = NULL, value = "188")
            ),
            column(2, actionButton(inputId = "remove8", label = "", icon = icon("times", class = NULL)))
          )),
        
        
        ## NINTH BASELINE STUDY
        tags$div(
          id = 9,
          fluidRow(
            column(2, textInput(inputId = "genetictest9", label = NULL, value = "EP")
            ),
            column(4, textInput(inputId = "studyname9", label = NULL, value = "Lemke et al, 2012")
            ),
            column(2, textInput(inputId = "ndiagnosed9", label = NULL, value = "16")
            ),
            column(2, textInput(inputId = "ntotal9", label = NULL, value = "33")
            ),
            column(2, actionButton(inputId = "remove9", label = "", icon = icon("times", class = NULL)))
          )),
        
        
        ## TENTH BASELINE STUDY
        tags$div(
          id = 10,
          fluidRow(
            column(2, textInput(inputId = "genetictest10", label = NULL, value = "EP")
            ),
            column(4, textInput(inputId = "studyname10", label = NULL, value = "Wang et al, 2014")
            ),
            column(2, textInput(inputId = "ndiagnosed10", label = NULL, value = "6")
            ),
            column(2, textInput(inputId = "ntotal10", label = NULL, value = "28")
            ),
            column(2, actionButton(inputId = "remove10", label = "", icon = icon("times", class = NULL)))
          )),

                
        ## ELEVENTH BASELINE STUDY
        tags$div(
          id = 11,
          fluidRow(
            column(2, textInput(inputId = "genetictest11", label = NULL, value = "EP")
            ),
            column(4, textInput(inputId = "studyname11", label = NULL, value = "Della Mina et al, 2015")
            ),
            column(2, textInput(inputId = "ndiagnosed11", label = NULL, value = "9")
            ),
            column(2, textInput(inputId = "ntotal11", label = NULL, value = "19")
            ),
            column(2, actionButton(inputId = "remove11", label = "", icon = icon("times", class = NULL)))
          )),        
        
  
        ## TWELTH BASELINE STUDY
        tags$div(
          id = 12,
          fluidRow(
            column(2, textInput(inputId = "genetictest12", label = NULL, value = "EP")
            ),
            column(4, textInput(inputId = "studyname12", label = NULL, value = "Mercimeck et al, 2015")
            ),
            column(2, textInput(inputId = "ndiagnosed12", label = NULL, value = "12")
            ),
            column(2, textInput(inputId = "ntotal12", label = NULL, value = "93")
            ),
            column(2, actionButton(inputId = "remove12", label = "", icon = icon("times", class = NULL)))
          )),         

                
        ## THIRTEENTH BASELINE STUDY
        tags$div(
          id = 13,
          fluidRow(
            column(2, textInput(inputId = "genetictest13", label = NULL, value = "EP")
            ),
            column(4, textInput(inputId = "studyname13", label = NULL, value = "Trump et al, 2016")
            ),
            column(2, textInput(inputId = "ndiagnosed13", label = NULL, value = "60")
            ),
            column(2, textInput(inputId = "ntotal13", label = NULL, value = "323")
            ),
            column(2, actionButton(inputId = "remove13", label = "", icon = icon("times", class = NULL)))
          )),         
              
 
        ## FOURTEENTH BASELINE STUDY
        tags$div(
          id = 14,
          fluidRow(
            column(2, textInput(inputId = "genetictest14", label = NULL, value = "EP")
            ),
            column(4, textInput(inputId = "studyname14", label = NULL, value = "Segal et al, 2016")
            ),
            column(2, textInput(inputId = "ndiagnosed14", label = NULL, value = "7")
            ),
            column(2, textInput(inputId = "ntotal14", label = NULL, value = "49")
            ),
            column(2, actionButton(inputId = "remove14", label = "", icon = icon("times", class = NULL)))
          )),         
        

        ## FIFTEENTH BASELINE STUDY
        tags$div(
          id = 15,
          fluidRow(
            column(2, textInput(inputId = "genetictest15", label = NULL, value = "EP")
            ),
            column(4, textInput(inputId = "studyname15", label = NULL, value = "Moller et al, 2016")
            ),
            column(2, textInput(inputId = "ndiagnosed15", label = NULL, value = "49")
            ),
            column(2, textInput(inputId = "ntotal15", label = NULL, value = "216")
            ),
            column(2, actionButton(inputId = "remove15", label = "", icon = icon("times", class = NULL)))
          )), 

        
        ## SIXTEENTH BASELINE STUDY
        tags$div(
          id = 16,
          fluidRow(
            column(2, textInput(inputId = "genetictest16", label = NULL, value = "EP")
            ),
            column(4, textInput(inputId = "studyname16", label = NULL, value = "Berg et al, 2017")
            ),
            column(2, textInput(inputId = "ndiagnosed16", label = NULL, value = "31")
            ),
            column(2, textInput(inputId = "ntotal16", label = NULL, value = "114")
            ),
            column(2, actionButton(inputId = "remove16", label = "", icon = icon("times", class = NULL)))
          )),
        

        ## SEVENTEENTH BASELINE STUDY
        tags$div(
          id = 17,
          fluidRow(
            column(2, textInput(inputId = "genetictest17", label = NULL, value = "EP")
            ),
            column(4, textInput(inputId = "studyname17", label = NULL, value = "Butler et al, 2017")
            ),
            column(2, textInput(inputId = "ndiagnosed17", label = NULL, value = "62")
            ),
            column(2, textInput(inputId = "ntotal17", label = NULL, value = "339")
            ),
            column(2, actionButton(inputId = "remove17", label = "", icon = icon("times", class = NULL)))
          )),
        
               
        ## EIGHTEENTH BASELINE STUDY
        tags$div(
          id = 18,
          fluidRow(
            column(2, textInput(inputId = "genetictest18", label = NULL, value = "WES")
            ),
            column(4, textInput(inputId = "studyname18", label = NULL, value = "Veeramah et al, 2013")
            ),
            column(2, textInput(inputId = "ndiagnosed18", label = NULL, value = "7")
            ),
            column(2, textInput(inputId = "ntotal18", label = NULL, value = "10")
            ),
            column(2, actionButton(inputId = "remove18", label = "", icon = icon("times", class = NULL)))
          )),     
   
             
        ## NINETEENTH BASELINE STUDY
        tags$div(
          id = 19,
          fluidRow(
            column(2, textInput(inputId = "genetictest19", label = NULL, value = "WES")
            ),
            column(4, textInput(inputId = "studyname19", label = NULL, value = "Michaud et al, 2014")
            ),
            column(2, textInput(inputId = "ndiagnosed19", label = NULL, value = "13")
            ),
            column(2, textInput(inputId = "ntotal19", label = NULL, value = "18")
            ),
            column(2, actionButton(inputId = "remove19", label = "", icon = icon("times", class = NULL)))
          )),      
        
 
        ## TWENTIETH BASELINE STUDY
        tags$div(
          id = 20,
          fluidRow(
            column(2, textInput(inputId = "genetictest20", label = NULL, value = "WES")
            ),
            column(4, textInput(inputId = "studyname20", label = NULL, value = "Dyment et al, 2015")
            ),
            column(2, textInput(inputId = "ndiagnosed20", label = NULL, value = "7")
            ),
            column(2, textInput(inputId = "ntotal20", label = NULL, value = "9")
            ),
            column(2, actionButton(inputId = "remove20", label = "", icon = icon("times", class = NULL)))
          )),        
        
        
        ## TWENTy-FIRST BASELINE STUDY
        tags$div(
          id = 21,
          fluidRow(
            column(2, textInput(inputId = "genetictest21", label = NULL, value = "WES")
            ),
            column(4, textInput(inputId = "studyname21", label = NULL, value = "Retterer et al, 2015")
            ),
            column(2, textInput(inputId = "ndiagnosed21", label = NULL, value = "232")
            ),
            column(2, textInput(inputId = "ntotal21", label = NULL, value = "830")
            ),
            column(2, actionButton(inputId = "remove21", label = "", icon = icon("times", class = NULL)))
          )),          
        

        ## TWENTy-SECOND BASELINE STUDY
        tags$div(
          id = 22,
          fluidRow(
            column(2, textInput(inputId = "genetictest22", label = NULL, value = "WES")
            ),
            column(4, textInput(inputId = "studyname22", label = NULL, value = "Helbig et al, 2016")
            ),
            column(2, textInput(inputId = "ndiagnosed22", label = NULL, value = "112")
            ),
            column(2, textInput(inputId = "ntotal22", label = NULL, value = "293")
            ),
            column(2, actionButton(inputId = "remove22", label = "", icon = icon("times", class = NULL)))
          )),         

        
        ## TWENTy-THIRD BASELINE STUDY
        tags$div(
          id = 23,
          fluidRow(
            column(2, textInput(inputId = "genetictest23", label = NULL, value = "WES")
            ),
            column(4, textInput(inputId = "studyname23", label = NULL, value = "Berg et al, 2017")
            ),
            column(2, textInput(inputId = "ndiagnosed23", label = NULL, value = "11")
            ),
            column(2, textInput(inputId = "ntotal23", label = NULL, value = "33")
            ),
            column(2, actionButton(inputId = "remove23", label = "", icon = icon("times", class = NULL)))
          ))
                        
#######################################################################################################################################################        
########################################END OF STUDIES THAT APPEAR AT BASELINE (IN THE EXISTING LITERATURE TODAY)#####################################                
      ) # End of fluidRow
      
      
    ), # End of sidebarPanel
    
#########################################END OF INPUT########################################################    







#########################################BEGINNING OF OUTPUT########################################################    
    ### OUTPUT
    mainPanel(
      # Beginning of mainPanel
      
      # Title
      tags$br(),
      tags$strong("OUTPUT"),    
      tags$br(),
      tags$br(),
      tags$strong("RANDOM EFFECTS META-ANALYSIS: scroll down as needed."),
      plotOutput("metaanalysis", width = 1000, height = 1000),
      tags$br(),
      tags$br(),
      tags$header("Ivan Sanchez Fernandez 2018. This work is copylefted under a General Public Licence (GPL)."),
      tags$header("Users are fee to run, study, and modify this software and to share and distribute original or modified versions of this software.")
      
#########################################END OF OUTPUT########################################################      
      
    ) # End of mainPanel
    
    
  ) # End of sidebarLayout
  
  # End of fluidPage  
)

##########################################################################################################################
##########################################################END OF UI################################################
##########################################################################################################################

















##########################################################################################################################
##########################################################BEGINNNING OF SERVER################################################
##########################################################################################################################

#### server.R
server <- function(input, output) {
  
  
  ## Keep track of elements inserted and not yet removed in the interactive reactivevalues list
  inserted <- reactiveValues(val = c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 
                                     21, 22, 23))
  
  ## Add a row (a new input) for inserting a new study and a number to the interactive reactivevalues list when "Add new study" button is pressed
  observeEvent(input$add, {
    id <- max(inserted$val) + 1
    insertUI(
      selector = "#placeholder",
      where = "beforeBegin",
      ui = tags$div(
        id = id,
        # Each identifier has the number of that row which is the same id that appears in the interactive reactivevalues list
        fluidRow(
          column(2, textInput(inputId = paste0("genetictest", id), label = NULL)
          ),
          column(4, textInput(inputId = paste0("studyname", id), label = NULL)
          ),
          column(2, textInput(inputId = paste0("ndiagnosed", id), label = NULL)
          ),
          column(2, textInput(inputId = paste0("ntotal", id), label = NULL)
          ),
          column(2, actionButton(inputId = paste0("remove", id), label = "", icon=icon("times", class = NULL))
          )
        ) 
      )
    )
    # Update the interactive reactivevalues list with the new number
    inserted$val <- c(inserted$val, id)
  })
  
  
  
  
  
  #############################################################################################################
  ####################################REMOVE UNWANTED ROWS##################################################### 
  #####################Values for rows 1 to 100 to allow for multiple potential changes in rows 
  
  # When the delete button is pushed, this row (the row with this number) is deleted 
  #and the inserted$val is updated taking out this number of row
  observeEvent(input$remove1,{
    removeUI(
      selector = paste0('#', 1)
    )
    inserted$val <- inserted$val[!inserted$val %in% 1]
  })    
  
  
  observeEvent(input$remove2,{
    removeUI(
      selector = paste0('#', 2)
    )
    inserted$val <- inserted$val[!inserted$val %in% 2]
  })   
  
  
  observeEvent(input$remove3,{
    removeUI(
      selector = paste0('#', 3)
    )
    inserted$val <- inserted$val[!inserted$val %in% 3]
  })    
  
  
  observeEvent(input$remove4,{
    removeUI(
      selector = paste0('#', 4)
    )
    inserted$val <- inserted$val[!inserted$val %in% 4]
  })  
  
  
  observeEvent(input$remove5,{
    removeUI(
      selector = paste0('#', 5)
    )
    inserted$val <- inserted$val[!inserted$val %in% 5]
  })    
  
  
  observeEvent(input$remove6,{
    removeUI(
      selector = paste0('#', 6)
    )
    inserted$val <- inserted$val[!inserted$val %in% 6]
  })   
  
  
  observeEvent(input$remove7,{
    removeUI(
      selector = paste0('#', 7)
    )
    inserted$val <- inserted$val[!inserted$val %in% 7]
  })    
  
  
  observeEvent(input$remove8,{
    removeUI(
      selector = paste0('#', 8)
    )
    inserted$val <- inserted$val[!inserted$val %in% 8]
  })  
  
  
  observeEvent(input$remove9,{
    removeUI(
      selector = paste0('#', 9)
    )
    inserted$val <- inserted$val[!inserted$val %in% 9]
  })    
  
  
  observeEvent(input$remove10,{
    removeUI(
      selector = paste0('#', 10)
    )
    inserted$val <- inserted$val[!inserted$val %in% 10]
  })   
  
  
  observeEvent(input$remove11,{
    removeUI(
      selector = paste0('#', 11)
    )
    inserted$val <- inserted$val[!inserted$val %in% 11]
  })    
  
  
  observeEvent(input$remove12,{
    removeUI(
      selector = paste0('#', 12)
    )
    inserted$val <- inserted$val[!inserted$val %in% 12]
  })   
  
  
  observeEvent(input$remove13,{
    removeUI(
      selector = paste0('#', 13)
    )
    inserted$val <- inserted$val[!inserted$val %in% 13]
  })    
  
  
  observeEvent(input$remove14,{
    removeUI(
      selector = paste0('#', 14)
    )
    inserted$val <- inserted$val[!inserted$val %in% 14]
  })  
  
  
  observeEvent(input$remove15,{
    removeUI(
      selector = paste0('#', 15)
    )
    inserted$val <- inserted$val[!inserted$val %in% 15]
  })    
  
  
  observeEvent(input$remove16,{
    removeUI(
      selector = paste0('#', 16)
    )
    inserted$val <- inserted$val[!inserted$val %in% 16]
  })   
  
  
  observeEvent(input$remove17,{
    removeUI(
      selector = paste0('#', 17)
    )
    inserted$val <- inserted$val[!inserted$val %in% 17]
  })    
  
  
  observeEvent(input$remove18,{
    removeUI(
      selector = paste0('#', 18)
    )
    inserted$val <- inserted$val[!inserted$val %in% 18]
  })  
  
  
  observeEvent(input$remove19,{
    removeUI(
      selector = paste0('#', 19)
    )
    inserted$val <- inserted$val[!inserted$val %in% 19]
  })    
  
  
  observeEvent(input$remove20,{
    removeUI(
      selector = paste0('#', 20)
    )
    inserted$val <- inserted$val[!inserted$val %in% 20]
  })     
  
  
  observeEvent(input$remove21,{
    removeUI(
      selector = paste0('#', 21)
    )
    inserted$val <- inserted$val[!inserted$val %in% 21]
  })    
  
  
  observeEvent(input$remove22,{
    removeUI(
      selector = paste0('#', 22)
    )
    inserted$val <- inserted$val[!inserted$val %in% 22]
  })   
  
  
  observeEvent(input$remove23,{
    removeUI(
      selector = paste0('#', 23)
    )
    inserted$val <- inserted$val[!inserted$val %in% 23]
  })    
  
  
  observeEvent(input$remove24,{
    removeUI(
      selector = paste0('#', 24)
    )
    inserted$val <- inserted$val[!inserted$val %in% 24]
  })  
  
  
  observeEvent(input$remove25,{
    removeUI(
      selector = paste0('#', 25)
    )
    inserted$val <- inserted$val[!inserted$val %in% 25]
  })    
  
  
  observeEvent(input$remove26,{
    removeUI(
      selector = paste0('#', 26)
    )
    inserted$val <- inserted$val[!inserted$val %in% 26]
  })   
  
  
  observeEvent(input$remove27,{
    removeUI(
      selector = paste0('#', 27)
    )
    inserted$val <- inserted$val[!inserted$val %in% 27]
  })    
  
  
  observeEvent(input$remove28,{
    removeUI(
      selector = paste0('#', 28)
    )
    inserted$val <- inserted$val[!inserted$val %in% 28]
  })  
  
  
  observeEvent(input$remove29,{
    removeUI(
      selector = paste0('#', 29)
    )
    inserted$val <- inserted$val[!inserted$val %in% 29]
  })    
  
  
  observeEvent(input$remove30,{
    removeUI(
      selector = paste0('#', 30)
    )
    inserted$val <- inserted$val[!inserted$val %in% 30]
  })    
  
  
  observeEvent(input$remove31,{
    removeUI(
      selector = paste0('#', 31)
    )
    inserted$val <- inserted$val[!inserted$val %in% 31]
  })    
  
  
  observeEvent(input$remove32,{
    removeUI(
      selector = paste0('#', 32)
    )
    inserted$val <- inserted$val[!inserted$val %in% 32]
  })   
  
  
  observeEvent(input$remove33,{
    removeUI(
      selector = paste0('#', 33)
    )
    inserted$val <- inserted$val[!inserted$val %in% 33]
  })    
  
  
  observeEvent(input$remove34,{
    removeUI(
      selector = paste0('#', 34)
    )
    inserted$val <- inserted$val[!inserted$val %in% 34]
  })  
  
  
  observeEvent(input$remove35,{
    removeUI(
      selector = paste0('#', 35)
    )
    inserted$val <- inserted$val[!inserted$val %in% 35]
  })    
  
  
  observeEvent(input$remove36,{
    removeUI(
      selector = paste0('#', 36)
    )
    inserted$val <- inserted$val[!inserted$val %in% 36]
  })   
  
  
  observeEvent(input$remove37,{
    removeUI(
      selector = paste0('#', 37)
    )
    inserted$val <- inserted$val[!inserted$val %in% 37]
  })    
  
  
  observeEvent(input$remove38,{
    removeUI(
      selector = paste0('#', 38)
    )
    inserted$val <- inserted$val[!inserted$val %in% 38]
  })  
  
  
  observeEvent(input$remove39,{
    removeUI(
      selector = paste0('#', 39)
    )
    inserted$val <- inserted$val[!inserted$val %in% 39]
  })    
  
  
  observeEvent(input$remove40,{
    removeUI(
      selector = paste0('#', 40)
    )
    inserted$val <- inserted$val[!inserted$val %in% 40]
  })    
  
  
  observeEvent(input$remove41,{
    removeUI(
      selector = paste0('#', 41)
    )
    inserted$val <- inserted$val[!inserted$val %in% 41]
  })    
  
  
  observeEvent(input$remove42,{
    removeUI(
      selector = paste0('#', 42)
    )
    inserted$val <- inserted$val[!inserted$val %in% 42]
  })   
  
  
  observeEvent(input$remove43,{
    removeUI(
      selector = paste0('#', 43)
    )
    inserted$val <- inserted$val[!inserted$val %in% 43]
  })    
  
  
  observeEvent(input$remove44,{
    removeUI(
      selector = paste0('#', 44)
    )
    inserted$val <- inserted$val[!inserted$val %in% 44]
  })  
  
  
  observeEvent(input$remove45,{
    removeUI(
      selector = paste0('#', 45)
    )
    inserted$val <- inserted$val[!inserted$val %in% 45]
  })    
  
  
  observeEvent(input$remove46,{
    removeUI(
      selector = paste0('#', 46)
    )
    inserted$val <- inserted$val[!inserted$val %in% 46]
  })   
  
  
  observeEvent(input$remove47,{
    removeUI(
      selector = paste0('#', 47)
    )
    inserted$val <- inserted$val[!inserted$val %in% 47]
  })    
  
  
  observeEvent(input$remove48,{
    removeUI(
      selector = paste0('#', 48)
    )
    inserted$val <- inserted$val[!inserted$val %in% 48]
  })  
  
  
  observeEvent(input$remove49,{
    removeUI(
      selector = paste0('#', 49)
    )
    inserted$val <- inserted$val[!inserted$val %in% 49]
  })    
  
  
  observeEvent(input$remove50,{
    removeUI(
      selector = paste0('#', 50)
    )
    inserted$val <- inserted$val[!inserted$val %in% 50]
  })   
  
  
  observeEvent(input$remove51,{
    removeUI(
      selector = paste0('#', 51)
    )
    inserted$val <- inserted$val[!inserted$val %in% 51]
  })    
  
  
  observeEvent(input$remove52,{
    removeUI(
      selector = paste0('#', 52)
    )
    inserted$val <- inserted$val[!inserted$val %in% 52]
  })   
  
  
  observeEvent(input$remove53,{
    removeUI(
      selector = paste0('#', 53)
    )
    inserted$val <- inserted$val[!inserted$val %in% 53]
  })    
  
  
  observeEvent(input$remove54,{
    removeUI(
      selector = paste0('#', 54)
    )
    inserted$val <- inserted$val[!inserted$val %in% 54]
  })  
  
  
  observeEvent(input$remove55,{
    removeUI(
      selector = paste0('#', 55)
    )
    inserted$val <- inserted$val[!inserted$val %in% 55]
  })    
  
  
  observeEvent(input$remove56,{
    removeUI(
      selector = paste0('#', 56)
    )
    inserted$val <- inserted$val[!inserted$val %in% 56]
  })   
  
  
  observeEvent(input$remove57,{
    removeUI(
      selector = paste0('#', 57)
    )
    inserted$val <- inserted$val[!inserted$val %in% 57]
  })    
  
  
  observeEvent(input$remove58,{
    removeUI(
      selector = paste0('#', 58)
    )
    inserted$val <- inserted$val[!inserted$val %in% 58]
  })  
  
  
  observeEvent(input$remove59,{
    removeUI(
      selector = paste0('#', 59)
    )
    inserted$val <- inserted$val[!inserted$val %in% 59]
  })    
  
  
  observeEvent(input$remove60,{
    removeUI(
      selector = paste0('#', 60)
    )
    inserted$val <- inserted$val[!inserted$val %in% 60]
  })     
  
  
  observeEvent(input$remove61,{
    removeUI(
      selector = paste0('#', 61)
    )
    inserted$val <- inserted$val[!inserted$val %in% 61]
  })    
  
  
  observeEvent(input$remove62,{
    removeUI(
      selector = paste0('#', 62)
    )
    inserted$val <- inserted$val[!inserted$val %in% 62]
  })   
  
  
  observeEvent(input$remove63,{
    removeUI(
      selector = paste0('#', 63)
    )
    inserted$val <- inserted$val[!inserted$val %in% 63]
  })    
  
  
  observeEvent(input$remove64,{
    removeUI(
      selector = paste0('#', 64)
    )
    inserted$val <- inserted$val[!inserted$val %in% 64]
  })  
  
  
  observeEvent(input$remove65,{
    removeUI(
      selector = paste0('#', 65)
    )
    inserted$val <- inserted$val[!inserted$val %in% 65]
  })    
  
  
  observeEvent(input$remove66,{
    removeUI(
      selector = paste0('#', 66)
    )
    inserted$val <- inserted$val[!inserted$val %in% 66]
  })   
  
  
  observeEvent(input$remove67,{
    removeUI(
      selector = paste0('#', 67)
    )
    inserted$val <- inserted$val[!inserted$val %in% 67]
  })    
  
  
  observeEvent(input$remove68,{
    removeUI(
      selector = paste0('#', 68)
    )
    inserted$val <- inserted$val[!inserted$val %in% 68]
  })  
  
  
  observeEvent(input$remove69,{
    removeUI(
      selector = paste0('#', 69)
    )
    inserted$val <- inserted$val[!inserted$val %in% 69]
  })    
  
  
  observeEvent(input$remove70,{
    removeUI(
      selector = paste0('#', 70)
    )
    inserted$val <- inserted$val[!inserted$val %in% 70]
  })   
  
  
  observeEvent(input$remove71,{
    removeUI(
      selector = paste0('#', 71)
    )
    inserted$val <- inserted$val[!inserted$val %in% 71]
  })    
  
  
  observeEvent(input$remove72,{
    removeUI(
      selector = paste0('#', 72)
    )
    inserted$val <- inserted$val[!inserted$val %in% 72]
  })   
  
  
  observeEvent(input$remove73,{
    removeUI(
      selector = paste0('#', 73)
    )
    inserted$val <- inserted$val[!inserted$val %in% 73]
  })    
  
  
  observeEvent(input$remove74,{
    removeUI(
      selector = paste0('#', 74)
    )
    inserted$val <- inserted$val[!inserted$val %in% 74]
  })  
  
  
  observeEvent(input$remove75,{
    removeUI(
      selector = paste0('#', 75)
    )
    inserted$val <- inserted$val[!inserted$val %in% 75]
  })    
  
  
  observeEvent(input$remove76,{
    removeUI(
      selector = paste0('#', 76)
    )
    inserted$val <- inserted$val[!inserted$val %in% 76]
  })   
  
  
  observeEvent(input$remove77,{
    removeUI(
      selector = paste0('#', 77)
    )
    inserted$val <- inserted$val[!inserted$val %in% 77]
  })    
  
  
  observeEvent(input$remove78,{
    removeUI(
      selector = paste0('#', 78)
    )
    inserted$val <- inserted$val[!inserted$val %in% 78]
  })  
  
  
  observeEvent(input$remove79,{
    removeUI(
      selector = paste0('#', 79)
    )
    inserted$val <- inserted$val[!inserted$val %in% 79]
  })    
  
  
  observeEvent(input$remove80,{
    removeUI(
      selector = paste0('#', 80)
    )
    inserted$val <- inserted$val[!inserted$val %in% 80]
  })   
  
  
  observeEvent(input$remove81,{
    removeUI(
      selector = paste0('#', 81)
    )
    inserted$val <- inserted$val[!inserted$val %in% 81]
  })    
  
  
  observeEvent(input$remove82,{
    removeUI(
      selector = paste0('#', 82)
    )
    inserted$val <- inserted$val[!inserted$val %in% 82]
  })   
  
  
  observeEvent(input$remove83,{
    removeUI(
      selector = paste0('#', 83)
    )
    inserted$val <- inserted$val[!inserted$val %in% 83]
  })    
  
  
  observeEvent(input$remove84,{
    removeUI(
      selector = paste0('#', 84)
    )
    inserted$val <- inserted$val[!inserted$val %in% 84]
  })  
  
  
  observeEvent(input$remove85,{
    removeUI(
      selector = paste0('#', 85)
    )
    inserted$val <- inserted$val[!inserted$val %in% 85]
  })    
  
  
  observeEvent(input$remove86,{
    removeUI(
      selector = paste0('#', 86)
    )
    inserted$val <- inserted$val[!inserted$val %in% 86]
  })   
  
  
  observeEvent(input$remove87,{
    removeUI(
      selector = paste0('#', 87)
    )
    inserted$val <- inserted$val[!inserted$val %in% 87]
  })    
  
  
  observeEvent(input$remove88,{
    removeUI(
      selector = paste0('#', 88)
    )
    inserted$val <- inserted$val[!inserted$val %in% 88]
  })  
  
  
  observeEvent(input$remove89,{
    removeUI(
      selector = paste0('#', 89)
    )
    inserted$val <- inserted$val[!inserted$val %in% 89]
  })    
  
  
  observeEvent(input$remove90,{
    removeUI(
      selector = paste0('#', 90)
    )
    inserted$val <- inserted$val[!inserted$val %in% 90]
  })   
  

  observeEvent(input$remove91,{
    removeUI(
      selector = paste0('#', 91)
    )
    inserted$val <- inserted$val[!inserted$val %in% 91]
  })    
  
  
  observeEvent(input$remove92,{
    removeUI(
      selector = paste0('#', 92)
    )
    inserted$val <- inserted$val[!inserted$val %in% 92]
  })   
  
  
  observeEvent(input$remove93,{
    removeUI(
      selector = paste0('#', 93)
    )
    inserted$val <- inserted$val[!inserted$val %in% 93]
  })    
  
  
  observeEvent(input$remove94,{
    removeUI(
      selector = paste0('#', 94)
    )
    inserted$val <- inserted$val[!inserted$val %in% 94]
  })  
  
  
  observeEvent(input$remove95,{
    removeUI(
      selector = paste0('#', 95)
    )
    inserted$val <- inserted$val[!inserted$val %in% 95]
  })    
  
  
  observeEvent(input$remove96,{
    removeUI(
      selector = paste0('#', 96)
    )
    inserted$val <- inserted$val[!inserted$val %in% 96]
  })   
  
  
  observeEvent(input$remove97,{
    removeUI(
      selector = paste0('#', 97)
    )
    inserted$val <- inserted$val[!inserted$val %in% 97]
  })    
  
  
  observeEvent(input$remove98,{
    removeUI(
      selector = paste0('#', 98)
    )
    inserted$val <- inserted$val[!inserted$val %in% 98]
  })  
  
  
  observeEvent(input$remove99,{
    removeUI(
      selector = paste0('#', 99)
    )
    inserted$val <- inserted$val[!inserted$val %in% 99]
  })    
  
  
  observeEvent(input$remove100,{
    removeUI(
      selector = paste0('#', 100)
    )
    inserted$val <- inserted$val[!inserted$val %in% 100]
  })   
  
  
  ####################################END OF REMOVE UNWANTED ROWS##################################################### 
###############################################################################################################  
  
  
  
  
  
  
  
############################################### CREATE METAANALYSIS PLOT#########################################
#################################################################################################################
  output$metaanalysis <- renderPlot({
    
    
## Collect the inputs
## Allow 100 inputs to allow for multiple changes in studies inputs and multiple studies
    
    # genetictests 
    genetictests <- c(input$genetictest1, input$genetictest2, input$genetictest3, input$genetictest4, input$genetictest5, 
              input$genetictest6, input$genetictest7, input$genetictest8, input$genetictest9, input$genetictest10, 
              input$genetictest11, input$genetictest12, input$genetictest13, input$genetictest14, input$genetictest15,
              input$genetictest16, input$genetictest17, input$genetictest18, input$genetictest19, input$genetictest20,
              input$genetictest21, input$genetictest22, input$genetictest23, input$genetictest24, input$genetictest25,
              input$genetictest26, input$genetictest27, input$genetictest28, input$genetictest29, input$genetictest30,
              input$genetictest31, input$genetictest32, input$genetictest33, input$genetictest34, input$genetictest35,
              input$genetictest36, input$genetictest37, input$genetictest38, input$genetictest39, input$genetictest40,
              input$genetictest41, input$genetictest42, input$genetictest43, input$genetictest44, input$genetictest45,
              input$genetictest46, input$genetictest47, input$genetictest48, input$genetictest49, input$genetictest50,
              input$genetictest51, input$genetictest52, input$genetictest53, input$genetictest54, input$genetictest55,
              input$genetictest56, input$genetictest57, input$genetictest58, input$genetictest59, input$genetictest60,
              input$genetictest61, input$genetictest62, input$genetictest63, input$genetictest64, input$genetictest65,
              input$genetictest66, input$genetictest67, input$genetictest68, input$genetictest69, input$genetictest70,
              input$genetictest71, input$genetictest72, input$genetictest73, input$genetictest74, input$genetictest75,
              input$genetictest76, input$genetictest77, input$genetictest78, input$genetictest79, input$genetictest80,
              input$genetictest81, input$genetictest82, input$genetictest83, input$genetictest84, input$genetictest85,
              input$genetictest86, input$genetictest87, input$genetictest88, input$genetictest89, input$genetictest90,
              input$genetictest91, input$genetictest92, input$genetictest93, input$genetictest94, input$genetictest95,
              input$genetictest96, input$genetictest97, input$genetictest98, input$genetictest99, input$genetictest100)
    # Consider only those genetictests from studies that have not been deleted and are in the interactive reactivevalues list 
    genetictests <- genetictests[inserted$val]
    
    
    
    # Studies
    studies <- c(input$studyname1, input$studyname2, input$studyname3, input$studyname4, input$studyname5, 
                 input$studyname6, input$studyname7, input$studyname8, input$studyname9, input$studyname10, 
                 input$studyname11, input$studyname12, input$studyname13, input$studyname14, input$studyname15,
                 input$studyname16, input$studyname17, input$studyname18, input$studyname19, input$studyname20,
                 input$studyname21, input$studyname22, input$studyname23, input$studyname24, input$studyname25,
                 input$studyname26, input$studyname27, input$studyname28, input$studyname29, input$studyname30,
                 input$studyname31, input$studyname32, input$studyname33, input$studyname34, input$studyname35,
                 input$studyname36, input$studyname37, input$studyname38, input$studyname39, input$studyname40,
                 input$studyname41, input$studyname42, input$studyname43, input$studyname44, input$studyname45,
                 input$studyname46, input$studyname47, input$studyname48, input$studyname49, input$studyname50,
                 input$studyname51, input$studyname52, input$studyname53, input$studyname54, input$studyname55,
                 input$studyname56, input$studyname57, input$studyname58, input$studyname59, input$studyname60,
                 input$studyname61, input$studyname62, input$studyname63, input$studyname64, input$studyname65,
                 input$studyname66, input$studyname67, input$studyname68, input$studyname69, input$studyname70,
                 input$studyname71, input$studyname72, input$studyname73, input$studyname74, input$studyname75,
                 input$studyname76, input$studyname77, input$studyname78, input$studyname79, input$studyname80,
                 input$studyname81, input$studyname82, input$studyname83, input$studyname84, input$studyname85,
                 input$studyname86, input$studyname87, input$studyname88, input$studyname89, input$studyname90,
                 input$studyname91, input$studyname92, input$studyname93, input$studyname94, input$studyname95,
                 input$studyname96, input$studyname97, input$studyname98, input$studyname99, input$studyname100)
    # Consider only those genetictests from studies that have not been deleted and are in the interactive reactivevalues list
    studies <- studies[inserted$val]
    
    
    # Number of patients who were diagnosed
    diagnosed <- c(input$ndiagnosed1, input$ndiagnosed2, input$ndiagnosed3, input$ndiagnosed4, input$ndiagnosed5, 
                   input$ndiagnosed6, input$ndiagnosed7, input$ndiagnosed8, input$ndiagnosed9, input$ndiagnosed10, 
                   input$ndiagnosed11, input$ndiagnosed12, input$ndiagnosed13, input$ndiagnosed14, input$ndiagnosed15,
                   input$ndiagnosed16, input$ndiagnosed17, input$ndiagnosed18, input$ndiagnosed19, input$ndiagnosed20,
                   input$ndiagnosed21, input$ndiagnosed22, input$ndiagnosed23, input$ndiagnosed24, input$ndiagnosed25,
                   input$ndiagnosed26, input$ndiagnosed27, input$ndiagnosed28, input$ndiagnosed29, input$ndiagnosed30,
                   input$ndiagnosed31, input$ndiagnosed32, input$ndiagnosed33, input$ndiagnosed34, input$ndiagnosed35,
                   input$ndiagnosed36, input$ndiagnosed37, input$ndiagnosed38, input$ndiagnosed39, input$ndiagnosed40,
                   input$ndiagnosed41, input$ndiagnosed42, input$ndiagnosed43, input$ndiagnosed44, input$ndiagnosed45,
                   input$ndiagnosed46, input$ndiagnosed47, input$ndiagnosed48, input$ndiagnosed49, input$ndiagnosed50,
                   input$ndiagnosed51, input$ndiagnosed52, input$ndiagnosed53, input$ndiagnosed54, input$ndiagnosed55,
                   input$ndiagnosed56, input$ndiagnosed57, input$ndiagnosed58, input$ndiagnosed59, input$ndiagnosed60,
                   input$ndiagnosed61, input$ndiagnosed62, input$ndiagnosed63, input$ndiagnosed64, input$ndiagnosed65,
                   input$ndiagnosed66, input$ndiagnosed67, input$ndiagnosed68, input$ndiagnosed69, input$ndiagnosed70,
                   input$ndiagnosed71, input$ndiagnosed72, input$ndiagnosed73, input$ndiagnosed74, input$ndiagnosed75,
                   input$ndiagnosed76, input$ndiagnosed77, input$ndiagnosed78, input$ndiagnosed79, input$ndiagnosed80,
                   input$ndiagnosed81, input$ndiagnosed82, input$ndiagnosed83, input$ndiagnosed84, input$ndiagnosed85,
                   input$ndiagnosed86, input$ndiagnosed87, input$ndiagnosed88, input$ndiagnosed89, input$ndiagnosed90,
                   input$ndiagnosed91, input$ndiagnosed92, input$ndiagnosed93, input$ndiagnosed94, input$ndiagnosed95,
                   input$ndiagnosed96, input$ndiagnosed97, input$ndiagnosed98, input$ndiagnosed99, input$ndiagnosed100)
    # Consider only those genetictests from studies that have not been deleted and are in the interactive reactivevalues list
    diagnosed <- diagnosed[inserted$val]
    
    
    # Total number of patients in the study
    total <- c(input$ntotal1, input$ntotal2, input$ntotal3, input$ntotal4, input$ntotal5, 
               input$ntotal6, input$ntotal7, input$ntotal8, input$ntotal9, input$ntotal10, 
               input$ntotal11, input$ntotal12, input$ntotal13, input$ntotal14, input$ntotal15,
               input$ntotal16, input$ntotal17, input$ntotal18, input$ntotal19, input$ntotal20,
               input$ntotal21, input$ntotal22, input$ntotal23, input$ntotal24, input$ntotal25,
               input$ntotal26, input$ntotal27, input$ntotal28, input$ntotal29, input$ntotal30,
               input$ntotal31, input$ntotal32, input$ntotal33, input$ntotal34, input$ntotal35,
               input$ntotal36, input$ntotal37, input$ntotal38, input$ntotal39, input$ntotal40,
               input$ntotal41, input$ntotal42, input$ntotal43, input$ntotal44, input$ntotal45,
               input$ntotal46, input$ntotal47, input$ntotal48, input$ntotal49, input$ntotal50,
               input$ntotal51, input$ntotal52, input$ntotal53, input$ntotal54, input$ntotal55,
               input$ntotal56, input$ntotal57, input$ntotal58, input$ntotal59, input$ntotal60,
               input$ntotal61, input$ntotal62, input$ntotal63, input$ntotal64, input$ntotal65,
               input$ntotal66, input$ntotal67, input$ntotal68, input$ntotal69, input$ntotal70,
               input$ntotal71, input$ntotal72, input$ntotal73, input$ntotal74, input$ntotal75,
               input$ntotal76, input$ntotal77, input$ntotal78, input$ntotal79, input$ntotal80,
               input$ntotal81, input$ntotal82, input$ntotal83, input$ntotal84, input$ntotal85,
               input$ntotal86, input$ntotal87, input$ntotal88, input$ntotal89, input$ntotal90,
               input$ntotal91, input$ntotal92, input$ntotal93, input$ntotal94, input$ntotal95,
               input$ntotal96, input$ntotal97, input$ntotal98, input$ntotal99, input$ntotal100)
    # Consider only those genetictests from studies that have not been deleted and are in the interactive reactivevalues list
    total <- total[inserted$val]
    

    # Collect the data for the metaanalysis in a metaprop object    
    dataformetaanalysis <- metaprop(
      # Patients who were diagnosed
      event = as.numeric(diagnosed),
      # Total number of patients in the study
      n = as.numeric(total),
      # Study names
      studlab = studies,
      # Classification variable (type of genetictest)
      byvar = genetictests
    )
    
    # Create the forest plot
    forestplot <- forest(dataformetaanalysis, comb.fixed = FALSE, lty.random = 2, lty.fixed = 0, 
                    xlim = c(0, 1), lwd = 1.75, col.study = "navy", col.square = "gray", col.square.lines = "navy",
                    col.diamond.random = "red", col.diamond.lines.random = "red",
                    print.I2 = TRUE, print.I2.ci = TRUE, print.tau2 = FALSE, print.pval.Q = FALSE,
                    fontsize = 16, fs.heading = 20, fs.hetstat = 16, fs.axis = 16, fs.test.overall = 16,
                    fs.random = 20, fs.smlab = 20, ff.study.labels =  "bold", 
                    ff.axis = "bold", squaresize = 1.2, 
                    backtransf = TRUE, test.overall.random = TRUE, 
                    leftcols = c("studlab", "effect", "ci"), rightcols = FALSE,
                    just = "right", digits = 2, print.byvar = FALSE, col.by = "blue", overall = FALSE) 
    
    # Render the forest plot
    forestplot
  })
  
  
  
}
##########################################################################################################################
##########################################################END OF SERVER################################################
##########################################################################################################################





##########################################################################################################################
##########################################################RUN THE APP WITH UI AND SERVER###############################################
##########################################################################################################################
#### Run the app
shinyApp(ui = ui, server = server)